from flask import Flask, render_template, jsonify
import requests

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/get_joke')
def get_joke():
    url = "https://official-joke-api.appspot.com/random_joke"
    response = requests.get(url)
    data = response.json()
    return jsonify({
        'setup': data['setup'],
        'punchline': data['punchline'],
        'type': data['type']
    })

@app.route('/get_joke/<category>')
def get_joke_by_category(category):
    url = f"https://official-joke-api.appspot.com/jokes/{category}/random"
    response = requests.get(url)
    data = response.json()

    # api returns a list for category jokes
    if isinstance(data, list):
        data = data[0]

    return jsonify({
        'setup': data['setup'],
        'punchline': data['punchline'],
        'type': data['type']
    })

if __name__ == '__main__':
    app.run(debug=True)
