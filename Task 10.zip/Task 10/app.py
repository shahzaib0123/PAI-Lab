from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

def get_response(message):
    message = message.lower()

    # Menu
    if "menu" in message or "food" in message or "eat" in message or "dish" in message:
        return ("Our menu includes: \n"
                "🍕 Pizza - Rs. 800\n"
                "🍔 Burger - Rs. 400\n"
                "🍝 Pasta - Rs. 600\n"
                "🥗 Salad - Rs. 300\n"
                "🍗 Grilled Chicken - Rs. 900\n"
                "🧃 Fresh Juice - Rs. 200\n"
                "Type 'deals' to see today's specials!")

    # Deals
    elif "deal" in message or "offer" in message or "special" in message or "discount" in message:
        return ("Today's Special Deals:\n"
                "🔥 Buy 1 Pizza Get 1 Free (lunch only)\n"
                "🔥 Family Meal Deal - Rs. 2000 (2 mains + 2 drinks)\n"
                "🔥 Student Discount - 10% off with ID card")

    # Reservation
    elif "reserv" in message or "book" in message or "table" in message or "seat" in message:
        return ("To make a reservation, please call us at:\n"
                "📞 0300-1234567\n"
                "Or visit us directly. We recommend booking 1 hour in advance on weekends.")

    # Hours / timing
    elif "hour" in message or "time" in message or "open" in message or "close" in message or "timing" in message:
        return ("Our opening hours are:\n"
                "Mon - Thu: 11:00 AM - 11:00 PM\n"
                "Fri - Sat: 11:00 AM - 12:00 AM\n"
                "Sunday: 12:00 PM - 10:00 PM")

    # Location
    elif "location" in message or "address" in message or "where" in message:
        return ("We are located at:\n"
                "📍 123 Food Street, Gulberg III, Lahore\n"
                "Near Liberty Roundabout. Parking is available.")

    # Order / delivery
    elif "order" in message or "deliver" in message or "home" in message:
        return ("We offer home delivery!\n"
                "📦 Delivery time: 30-45 minutes\n"
                "💵 Minimum order: Rs. 500\n"
                "Delivery charges: Rs. 100 (free above Rs. 1500)\n"
                "Call 0300-1234567 to place your order.")

    # Price / cost
    elif "price" in message or "cost" in message or "rate" in message or "cheap" in message:
        return ("Our prices are very affordable!\n"
                "Starters: Rs. 200 - 400\n"
                "Main Course: Rs. 400 - 900\n"
                "Drinks: Rs. 100 - 300\n"
                "Desserts: Rs. 150 - 350\n"
                "Type 'menu' to see full details.")

    # Contact
    elif "contact" in message or "phone" in message or "number" in message or "call" in message:
        return ("You can reach us at:\n"
                "📞 Phone: 0300-1234567\n"
                "📧 Email: info@tastyrestaurant.com\n"
                "📸 Instagram: @tastyrestaurant")

    # Greeting
    elif any(word in message for word in ["hi", "hello", "hey", "salam", "assalam"]):
        return "Hello! Welcome to Tasty Restaurant 🍽️ How can I help you today? You can ask me about our menu, deals, reservations, timings, or delivery!"

    # Thanks
    elif "thank" in message or "thanks" in message or "shukriya" in message:
        return "You're welcome! 😊 Visit us soon. Enjoy your meal! 🍽️"

    # Bye
    elif "bye" in message or "goodbye" in message or "khuda hafiz" in message:
        return "Goodbye! Hope to see you soon at Tasty Restaurant! 👋"

    # Default
    else:
        return ("Sorry, I didn't understand that. 🤔\n"
                "You can ask me about:\n"
                "- Menu\n"
                "- Deals & Offers\n"
                "- Reservations\n"
                "- Opening Hours\n"
                "- Location\n"
                "- Delivery\n"
                "- Contact")


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/chat', methods=['POST'])
def chat():
    user_msg = request.json.get('message', '')
    reply = get_response(user_msg)
    return jsonify({'reply': reply})


if __name__ == '__main__':
    app.run(debug=True)
