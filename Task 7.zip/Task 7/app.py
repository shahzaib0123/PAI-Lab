from flask import Flask, render_template, request
import requests

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/search', methods=['POST'])
def search():
    vin = request.form['vin']
    url = f"https://vpic.nhtsa.dot.gov/api/vehicles/DecodeVinValues/{vin}?format=json"
    response = requests.get(url)
    data = response.json()
    result = data['Results'][0]
    return render_template('index.html', result=result, vin=vin)

if __name__ == '__main__':
    app.run(debug=True)
